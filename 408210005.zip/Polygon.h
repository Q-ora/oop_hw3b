#ifndef _POLYGON_H_
#define _POLYGON_H_

#include "LinkedList.h"
class Polygon {
public:
    Polygon(); // constructor
    ~Polygon(); // destructor
    // While coding, please insert a line
    // cout << “Constructing Polygon…” << endl;
    // and
    // cout << “Deleting Polygon…” << endl;
    // in the body of constructor and destructor, respectively.

    // It takes an array of points and forms a polygon
    void setPolygon( Point pts[], int size );

    Polygon* splitPolygon(); // To be implemented
    bool isCollide( Polygon& inPolygon ); // To be implemented
    
    // The input edge is defined by 2 end points − ptA and ptB
    // This function returns true if the input edge intersects
    // or touches this polygon. Otherwise, it returns false.
    // Implemented for you
    bool isEdgeIntersect( const Point& ptA, const Point& ptB );

private:
    LinkedList vertexList; // The circular doubly linked list
};

#endif