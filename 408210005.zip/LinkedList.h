#ifndef _LINKEDLIST_H_
#define _LINKEDLIST_H_

struct Point {
    int flag;   //插入到前面或是後面
    int x;  // x−coordinate
    int y;  // y−coordinate
};
struct Node {
    Point pt;
    Node *next, *prev;
};

class LinkedList {
public:
    LinkedList();   // constructor
    ~LinkedList();  // destructor
    // Please add an informative message in constructor and destructor:
    // cout << “Constructing LinkedList…” << endl;
    // cout << “Deleting LinkedList…” << endl;
    
    int getSize() const;    // return the number of elements (node) of the linked list
    bool isEmpty() const;   // return true if the list is empty
    void clear();   // make the circular doubly linked list empty
    void deleteCurrentNode();    // delete the current node. The current pointer will point to the next node of the deleted node
    void pointToNext();     // make the current_pointer point to the next node
    void pointToPrev();     // make the current_pointer point to the previous node
    Point getCurrentPoint() const;  // return the Point pointed by the current_pointer
    void insertToNext( const Point& pt );   // insert a Point next to the current node
    void insertToPrev( const Point& pt );   // insert a Point before the current node

private:
    // The current pointer. It points to the current node.
    // If the linked list is empty, it equals to NULL.
    Node* current_pointer;
};

#endif