姓名: 謝宗哲
學號: 408210005
email: steven900412@gmail.com
完成項目:
    1. 讀取polydata.txt裡的數字, 放到pts陣列裡
    2. 完成Polygon和LinkedList的成員函式實作, 並在每個函式執行時輸出訊息
    3. 函式訊息會輸出到螢幕上