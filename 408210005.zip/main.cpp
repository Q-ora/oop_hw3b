#include "LinkedList.h"
#include "Polygon.h"
#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream fin("polydata.txt");

    Polygon a, b;
    Polygon *copy_a;

    int size1 = 0, size2 = 0;
    Point pts1[100], pts2[100];

    //read polydata, fill in flag[] and pts[]
    for(int i=0; ; i++ ){
        fin >> pts1[i].flag;
        if(pts1[i].flag == -1){
            size1 = i;
            break;
        }

        fin >> pts1[i].x >> pts1[i].y;
    }
    for(int i=0; ; i++ ){
        fin >> pts2[i].flag;
        if(pts2[i].flag == -1){
            size2 = i;
            break;
        }

        fin >> pts2[i].x >> pts2[i].y;
    }

    // TEST
    a.setPolygon(pts1, size1);
    b.setPolygon(pts2, size2);

    a.isCollide(b);

    copy_a = a.splitPolygon();
    copy_a->isCollide(b);


    return 0;
}