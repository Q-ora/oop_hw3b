#include "Polygon.h"
#include <iostream>
#include <algorithm>

Polygon::Polygon() {
    std::cout << "Constructing Polygon..." << std::endl;
}

Polygon::~Polygon() {
    std::cout << "Deleting Polygon..." << std::endl;
}

void Polygon::setPolygon( Point pts[], int size ) {   //***待修改***
    std::cout << "Setting Polygon..." << std::endl;

    vertexList.clear();

    for(int i=0; i<size; i++)
    {
        if(pts[i].flag == -1)
            break;

        if(pts[i].flag == 1){
            vertexList.insertToPrev( pts[i] );
        }

        if(pts[i].flag == 2){
            vertexList.insertToNext( pts[i] );
        }
    }

    std::cout << "Setting Polygon COMPLETE!" << std::endl;
}

Polygon* Polygon::splitPolygon() {
    int N = this->vertexList.getSize();     // N = size
    if( N <= 3 ) {
        std::cout << "N<=3, cannot splitPolygon" << std::endl;
        return 0;
    }

    int M = N/2 + 1;

    std::cout << "Splitting Polygon..." << std::endl;

    // copy M vertices to replica
    Polygon *replica = new Polygon;
    for(int i=1; i<=M; i++){
        Point copy_pt = this->vertexList.getCurrentPoint();
        replica->vertexList.insertToNext(copy_pt);
        this->vertexList.pointToNext();
    }
    // delete node(M+1) ~ node(N)
    for(int i=M+1; i<=N; i++){
        this->vertexList.deleteCurrentNode();
    }

    std::cout << "Splitting COMPLETE!" << std::endl;

    return replica;
}

bool Polygon::isCollide( Polygon& inPolygon ) {
    std::cout << "Checking if isCollide..." << std::endl;

    // if one of the polygon contains no vertices, return false
    if( this->vertexList.isEmpty() || inPolygon.vertexList.isEmpty() ){
        std::cout << "*********************" << std::endl;
        std::cout << "*** NOT collide!! ***" << std::endl;
        std::cout << "*********************" << std::endl;
        return false;
    }

    // For each edge in inPolygon, test whether the edge intersects or touches this polygon.
    int size = inPolygon.vertexList.getSize();  // node數 = edge數    
    for( int i=0; i<size; i++ ){  //each edge(2 points: pt1, pt2) in inPolygon
        //取得current point 和 next point
        Point pt1 = inPolygon.vertexList.getCurrentPoint();
        inPolygon.vertexList.pointToNext();
        Point pt2 = inPolygon.vertexList.getCurrentPoint();

        if( this->isEdgeIntersect(pt1, pt2) ){
            std::cout << "*****************" << std::endl;
            std::cout << "*** Collide!! ***" << std::endl;
            std::cout << "*****************" << std::endl;
            return true;
        }
    }

    std::cout << "*********************" << std::endl;
    std::cout << "*** NOT collide!! ***" << std::endl;
    std::cout << "*********************" << std::endl;
    return false;
}

//-------------isEdgeIntersect------------------
// checks if point q lies on line segment p-r
bool onSegment(Point p, Point q, Point r)
{
    if (q.x <= std::max(p.x, r.x) && q.x >= std::min(p.x, r.x) &&
        q.y <= std::max(p.y, r.y) && q.y >= std::min(p.y, r.y))
       return true;
 
    return false;
}
 
// To find orientation of ordered triplet (p, q, r).
// 0 --> p, q and r are colinear
// 1 --> Clockwise
// 2 --> Counterclockwise
int orientation(Point p, Point q, Point r)
{
    // reference from http://www.dcs.gla.ac.uk/~pat/52233/slides/Geometry1x1.pdf
    int val = (q.y - p.y) * (r.x - q.x)-(q.x - p.x) * (r.y - q.y);
 
    if (val == 0) return 0;  // colinear
 
    return (val > 0)? 1: 2; // clock or counterclock wise
}

// line segment p1-q1 and line segent p2-q2 have intersection point or not.
bool doIntersect(Point p1, Point q1, Point p2, Point q2)
{
    //Find four orientations needed for general and special case 
    int o1 = orientation(p1, q1, p2);
    int o2 = orientation(p1, q1, q2);
    int o3 = orientation(p2, q2, p1);
    int o4 = orientation(p2, q2, q1);
 
    // General case- line segment A crosses  line segment B, looks like shape X.
    if (o1 != o2 && o3 != o4)
        return true;
 
    // Special Cases-one end point of line segment A(p1-q1 or p2-q2) lie s on line segment B(p2-q2 or p1-q1), looks like shape T.
    if (o1 == 0 && onSegment(p1, p2, q1)) return true;
 
    if (o2 == 0 && onSegment(p1, q2, q1)) return true;
 
    if (o3 == 0 && onSegment(p2, p1, q2)) return true;
 
    if (o4 == 0 && onSegment(p2, q1, q2)) return true;
 
    return false;
}

bool Polygon::isEdgeIntersect(const Point& ptA, const Point& ptB)
{
    std::cout << "Checking if isEdgeIntersect..." << std::endl;
 	Point polystart, polyend;
 	bool flag=false;
 	int count=0;
 	int size=vertexList.getSize();
 	if(size>=3)
 	{
		count=0;	
		while(count<=size)
		{
	  		polystart=vertexList.getCurrentPoint();
			vertexList.pointToNext();
	  		polyend=vertexList.getCurrentPoint();
	  		
	       		flag=doIntersect(ptA, ptB, polystart, polyend);
	       		if(flag==true)
				break;	
			count++;
	 	}
	 }
	 else
        std::cout<<"This is not a polygon"<<std::endl;

    std::cout << "Checking isEdgeIntersect COMPLETE!" << std::endl;
    return flag;
}
