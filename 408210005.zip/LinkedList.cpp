#include "LinkedList.h"
#include <iostream>

LinkedList::LinkedList() {
    std::cout << "Constructing LinkedList..." << std::endl;

    current_pointer = 0;
}

LinkedList::~LinkedList() {
    std::cout << "Deleting LinkedList..." << std::endl;

    clear();
}

int LinkedList::getSize() const {
    if(!current_pointer){    //size=0
        std::cout << "size is 0" << std::endl;
        return 0;
    }

    //size >= 1
    int size = 1;
    Node *tmp = current_pointer->next;    //current_pointer當作第一個node
    while(tmp != current_pointer){
        size++;
        tmp = tmp->next;
    }

    std::cout << "size is " << size << std::endl;
    return size;
}

bool LinkedList::isEmpty() const {
    if(current_pointer){
        std::cout << "not empty" << std::endl;
        return false;
    }else{
        std::cout << "is empty" << std::endl;
        return true;
    }
}

void LinkedList::clear() {
    if(!current_pointer){
        std::cout << "linked list cleared" << std::endl;
        return;
    }

    Node *next = current_pointer;
    current_pointer->prev->next = 0;    //把current node前一個node的next指向NULL
    while(current_pointer){
        next = current_pointer->next;
        delete current_pointer;
        std::cout << "node deleted" << std::endl;
        current_pointer = next;
    }

    std::cout << "linked list cleared" << std::endl;
}

void LinkedList::deleteCurrentNode() {
    if(!current_pointer){
        std::cout << "current node doesn't exist" << std::endl;
        return;
    }
    if(current_pointer->next == current_pointer){    //only one node
        Node *tmp = current_pointer;
        current_pointer = 0;
        delete tmp;
        std::cout << "current node deleted" << std::endl;
        return;
    }

    //size >= 2
    Node *tmp = current_pointer, *prev = current_pointer->prev;
    current_pointer = current_pointer->next;
    delete tmp;
    std::cout << "current node deleted" << std::endl;

    //接起來
    prev->next = current_pointer;
    current_pointer->prev = prev;
}

void LinkedList::pointToNext() {
    if(!current_pointer)
        return;

    current_pointer = current_pointer->next;
    std::cout << "point to next" << std::endl;
}

void LinkedList::pointToPrev() {
    if(!current_pointer)
        return;

    current_pointer = current_pointer->prev;
    std::cout << "point to prev" << std::endl;
}

Point LinkedList::getCurrentPoint() const {
    std::cout << "current point: (" \
            << current_pointer->pt.x << "," << current_pointer->pt.y 
            << ")" << std::endl;
    return current_pointer->pt;
}

void LinkedList::insertToNext( const Point& pt ) {
    //no node in linked list
    if(!current_pointer){
        current_pointer = new Node;
        std::cout << "new node constructed" << std::endl;
        current_pointer->pt = pt;
        current_pointer->prev = current_pointer, current_pointer->next = current_pointer;   //prev和next都指向自己
        std::cout << "first node inserted" << std::endl;
        return;
    }

    //size >= 1
    //insert new node
    Node *insert = new Node;
    std::cout << "new node constructed" << std::endl;
    insert->pt = pt;
    insert->prev = current_pointer;
    insert->next = current_pointer->next;

    current_pointer->next->prev = insert;
    current_pointer->next = insert;

    //current_pointer指向新的node
    current_pointer = insert;
    std::cout << "insert to next" << std::endl;
}

void LinkedList::insertToPrev( const Point& pt ) {
    //no node in linked list
    if(!current_pointer){
        current_pointer = new Node;
        std::cout << "new node constructed" << std::endl;
        current_pointer->pt = pt;
        current_pointer->prev = current_pointer, current_pointer->next = current_pointer;
        std::cout << "first node inserted" << std::endl;
        return;
    }

    //size >= 1
    //insert new node
    Node *insert = new Node;
    insert->pt = pt;
    insert->prev = current_pointer->prev;
    insert->next = current_pointer;

    current_pointer->prev->next = insert;
    current_pointer->prev = insert;

    //current_pointer指向新的node
    current_pointer = insert;
    std::cout << "insert to prev" << std::endl;
}

